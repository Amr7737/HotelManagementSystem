package models;

public class Booking {

    private int bookingId;
    private String guestName;
    private String roomNumber;

    public Booking(int bookingId,
                   String guestName,
                   String roomNumber) {

        this.bookingId = bookingId;
        this.guestName = guestName;
        this.roomNumber = roomNumber;
    }

    public int getBookingId() {
        return bookingId;
    }

    public String getGuestName() {
        return guestName;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    @Override
    public String toString() {

        return "Booking ID: " + bookingId
                + "\nGuest Name: " + guestName
                + "\nRoom Number: " + roomNumber;
    }
}