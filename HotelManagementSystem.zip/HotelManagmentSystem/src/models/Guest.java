package models;

public class Guest extends Person {

    private int guestId;

    public Guest(int guestId, String name, String phone) {
        super(name, phone);
        this.guestId = guestId;
    }

    @Override
    public void display() {
        System.out.println("Guest ID: " + guestId + " | Name: " + name);
    }
}