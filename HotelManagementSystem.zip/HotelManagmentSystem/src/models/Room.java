package models;

public class Room {

    protected String roomNumber;
    protected String roomType;
    protected double price;
    protected String status;

    public Room() {
    }

    public Room(String roomNumber,
                String roomType,
                double price,
                String status) {

        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.price = price;
        this.status = status;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

   
    public double calculatePrice() {
        return price;
    }

    @Override
    public String toString() {

        return "Room Number: " + roomNumber
                + "\nType: " + roomType
                + "\nPrice: " + price
                + "\nStatus: " + status;
    }
}