package models;

public class DoubleRoom extends Room {

    public DoubleRoom() {
        super();
    }

    @Override
    public double calculatePrice() {
        return 800;
    }
}