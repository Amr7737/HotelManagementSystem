package models;

public class SingleRoom extends Room {

    public SingleRoom() {
        super();
    }

    @Override
    public double calculatePrice() {
        return 500;
    }
}