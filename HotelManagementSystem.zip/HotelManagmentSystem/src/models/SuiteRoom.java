package models;

public class SuiteRoom extends Room {

    public SuiteRoom() {
        super();
    }

    @Override
    public double calculatePrice() {
        return 1500;
    }
}