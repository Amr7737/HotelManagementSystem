package models;

public class Person {

    protected String name;
    protected String phone;

    public Person(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }

    public void display() {
        System.out.println(name + " - " + phone);
    }
}