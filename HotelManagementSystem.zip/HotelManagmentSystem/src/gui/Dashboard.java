package gui;

import services.RoomService;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame {

    private JButton searchBtn;
    private JButton bookBtn;
    private JButton cancelBtn;
    private JButton showBtn;

    private RoomService service;

    public Dashboard() {

        service = new RoomService();

        setTitle("Hotel Management System");
        setSize(500, 300);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("Hotel Dashboard");
        title.setBounds(180, 20, 200, 30);

        searchBtn = new JButton("Search Room");
        searchBtn.setBounds(150, 80, 180, 30);

        bookBtn = new JButton("Book Room");
        bookBtn.setBounds(150, 130, 180, 30);

        cancelBtn = new JButton("Cancel Booking");
        cancelBtn.setBounds(150, 180, 180, 30);
         showBtn = new JButton("Show All Rooms");
         showBtn.setBounds(150, 230, 180, 30);

add(showBtn);
        add(title);
        add(searchBtn);
        add(bookBtn);
        add(cancelBtn);

        // Search
        searchBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String roomNumber =
                        JOptionPane.showInputDialog(
                                "Enter Room Number");

                if (roomNumber != null &&
                        !roomNumber.trim().isEmpty()) {

                    String result =
                            service.searchRoom(roomNumber);

                    JOptionPane.showMessageDialog(
                            null,
                            result
                    );
                }
            }
        });

        // Book
        bookBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String roomNumber =
                        JOptionPane.showInputDialog(
                                "Enter Room Number To Book");

                if (roomNumber != null &&
                        !roomNumber.trim().isEmpty()) {

                    String result =
                            service.bookRoom(roomNumber);

                    JOptionPane.showMessageDialog(
                            null,
                            result
                    );
                }
            }
        });

        // Cancel Booking
        cancelBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String roomNumber =
                        JOptionPane.showInputDialog(
                                "Enter Room Number To Cancel");

                if (roomNumber != null &&
                        !roomNumber.trim().isEmpty()) {

                    String result =
                            service.cancelBooking(roomNumber);

                    JOptionPane.showMessageDialog(
                            null,
                            result
                    );
                }
            }
        });
     showBtn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {

        new RoomsForm();
    }
});
        setVisible(true);
    }
}