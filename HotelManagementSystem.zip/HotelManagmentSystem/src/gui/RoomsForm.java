package gui;

import services.RoomService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;

public class RoomsForm extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private RoomService service;

    public RoomsForm() {

        service = new RoomService();

        setTitle("All Rooms");
        setSize(600, 400);
        setLocationRelativeTo(null);

        model = new DefaultTableModel();

        model.addColumn("Room Number");
        model.addColumn("Type");
        model.addColumn("Price");
        model.addColumn("Status");

        table = new JTable(model);

        loadRooms();

        add(new JScrollPane(table));

        setVisible(true);
    }

    private void loadRooms() {

        try {

            ResultSet rs = service.getAllRooms();

            while (rs.next()) {

                model.addRow(new Object[]{
                        rs.getString("room_number"),
                        rs.getString("room_type"),
                        rs.getDouble("price"),
                        rs.getString("status")
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}