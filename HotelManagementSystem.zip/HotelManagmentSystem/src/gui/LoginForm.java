package gui;

import javax.swing.*;

public class LoginForm extends JFrame {

    public LoginForm() {

        setTitle("Login");
        setSize(300,200);
        setLayout(null);

        JTextField user = new JTextField();
        JPasswordField pass = new JPasswordField();

        user.setBounds(50,50,150,25);
        pass.setBounds(50,80,150,25);

        JButton login = new JButton("Login");
        login.setBounds(80,120,100,30);

        add(user);
        add(pass);
        add(login);

        login.addActionListener(e -> {

            if(user.getText().equals("admin")
                    && String.valueOf(pass.getPassword()).equals("1234")) {

                new Dashboard();
                dispose();
            }
        });

        setVisible(true);
        setLocationRelativeTo(null);
    }
}