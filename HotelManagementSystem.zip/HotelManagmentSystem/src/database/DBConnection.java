package database;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() {

        try {

            Class.forName("org.sqlite.JDBC");

            Connection con =
                    DriverManager.getConnection("jdbc:sqlite:hotel.db");

            return con;

        } catch (Exception e) {

            e.printStackTrace();
            return null;
        }
    }
}
