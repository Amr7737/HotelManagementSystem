package database;

import java.sql.Connection;
import java.sql.Statement;

public class CreateDB {

    public static void main(String[] args) {

        try {

            Connection con = DBConnection.getConnection();

            if (con == null) {
                System.out.println("Database Connection Failed");
                return;
            }

            Statement st = con.createStatement();

            st.execute(
                    "CREATE TABLE IF NOT EXISTS rooms (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                            "room_number TEXT," +
                            "room_type TEXT," +
                            "price REAL," +
                            "status TEXT)"
            );

            // Single Rooms
            for (int i = 101; i <= 110; i++) {
                st.executeUpdate(
                        "INSERT INTO rooms(room_number,room_type,price,status) " +
                                "VALUES('" + i + "','Single',500,'Available')"
                );
            }

            // Double Rooms
            for (int i = 201; i <= 210; i++) {
                st.executeUpdate(
                        "INSERT INTO rooms(room_number,room_type,price,status) " +
                                "VALUES('" + i + "','Double',800,'Available')"
                );
            }

            // Suite Rooms
            for (int i = 301; i <= 305; i++) {
                st.executeUpdate(
                        "INSERT INTO rooms(room_number,room_type,price,status) " +
                                "VALUES('" + i + "','Suite',1500,'Available')"
                );
            }

            System.out.println("Database Created Successfully");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}