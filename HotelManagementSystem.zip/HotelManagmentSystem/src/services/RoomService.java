package services;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RoomService {

    // Search Room
    public String searchRoom(String roomNumber) {

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps =
                        con.prepareStatement(
                                "SELECT * FROM rooms WHERE room_number=?")
        ) {

            ps.setString(1, roomNumber);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    return "Room Number: "
                            + rs.getString("room_number")
                            + "\nType: "
                            + rs.getString("room_type")
                            + "\nPrice: "
                            + rs.getDouble("price")
                            + "\nStatus: "
                            + rs.getString("status");
                }
            }

            return "Room Not Found";

        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }
    }

    // Book Room
    public String bookRoom(String roomNumber) {

        try (
                Connection con = DBConnection.getConnection()
        ) {

            PreparedStatement check =
                    con.prepareStatement(
                            "SELECT * FROM rooms WHERE room_number=?");

            check.setString(1, roomNumber);

            ResultSet rs = check.executeQuery();

            if (!rs.next()) {
                return "Room Not Found";
            }

            if (rs.getString("status")
                    .equalsIgnoreCase("Booked")) {

                return "Room Already Booked";
            }

            PreparedStatement ps =
                    con.prepareStatement(
                            "UPDATE rooms SET status='Booked' WHERE room_number=?");

            ps.setString(1, roomNumber);

            ps.executeUpdate();

            return "Room Booked Successfully"
                    + "\nRoom Number: "
                    + rs.getString("room_number")
                    + "\nType: "
                    + rs.getString("room_type")
                    + "\nPrice: "
                    + rs.getDouble("price")
                    + "\nStatus: Booked";

        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }
    }

    // Cancel Booking
    public String cancelBooking(String roomNumber) {

        try (
                Connection con = DBConnection.getConnection()
        ) {

            PreparedStatement check =
                    con.prepareStatement(
                            "SELECT * FROM rooms WHERE room_number=?");

            check.setString(1, roomNumber);

            ResultSet rs = check.executeQuery();

            if (!rs.next()) {
                return "Room Not Found";
            }

            if (rs.getString("status")
                    .equalsIgnoreCase("Available")) {

                return "Room Is Already Available";
            }

            PreparedStatement ps =
                    con.prepareStatement(
                            "UPDATE rooms SET status='Available' WHERE room_number=?");

            ps.setString(1, roomNumber);

            ps.executeUpdate();

            return "Booking Cancelled Successfully"
                    + "\nRoom Number: "
                    + rs.getString("room_number")
                    + "\nType: "
                    + rs.getString("room_type")
                    + "\nPrice: "
                    + rs.getDouble("price")
                    + "\nStatus: Available";

        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }
    }

    // Show All Rooms
    public ResultSet getAllRooms() {

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(
                            "SELECT * FROM rooms ORDER BY room_number");

            return ps.executeQuery();

        } catch (Exception e) {

            e.printStackTrace();
            return null;
        }
    }
}