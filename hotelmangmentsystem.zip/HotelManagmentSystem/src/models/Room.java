package models;

public class Room {

    private int id;
    private String number;
    private String type;
    private double price;
    private String status;

    public Room(int id, String number, String type, double price, String status) {
        this.id = id;
        this.number = number;
        this.type = type;
        this.price = price;
        this.status = status;
    }

    public void showRoom() {
        System.out.println(number + " | " + type + " | " + status);
    }
}